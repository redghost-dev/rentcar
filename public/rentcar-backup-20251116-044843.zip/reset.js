// localStorage reset script
localStorage.removeItem('vehicles');
localStorage.removeItem('siteSettings');
console.log('localStorage temizlendi. Sayfayı yenile.');
