// ============================================
// API Wrapper - db.js'den inline olarak eklenmiş
// ============================================
const DB = {
    // Dinamik API URL - production ve local için
    get API_URL() {
        const isProduction = window.location.hostname === 'www.kiralikcar.com' || 
                            window.location.hostname === 'kiralikcar.com' ||
                            !window.location.hostname.includes('localhost');
        
        return isProduction 
            ? `${window.location.protocol}//${window.location.hostname}/api`
            : `${window.location.protocol}//${window.location.hostname}:3000/api`;
    },

    // Araçları sunucudan al
    async getVehicles() {
        try {
            const response = await fetch(`${this.API_URL}/vehicles`);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const data = await response.json();
            return data;
        } catch (e) {
            console.error('Araçları getirme hatası:', e);
            return [];
        }
    },

    // Yeni araç ekle
    async addVehicle(vehicle) {
        try {
            const response = await fetch(`${this.API_URL}/vehicles`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(vehicle)
            });
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            return await response.json();
        } catch (e) {
            console.error('Araç eklenme hatası:', e);
            throw e;
        }
    },

    // Araç güncelle
    async updateVehicle(id, vehicle) {
        try {
            const response = await fetch(`${this.API_URL}/vehicles/${id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(vehicle)
            });
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            return await response.json();
        } catch (e) {
            console.error('Araç güncelleme hatası:', e);
            throw e;
        }
    },

    // Araç sil
    async deleteVehicle(id) {
        try {
            const response = await fetch(`${this.API_URL}/vehicles/${id}`, {
                method: 'DELETE'
            });
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            return await response.json();
        } catch (e) {
            console.error('Araç silme hatası:', e);
            throw e;
        }
    }
};

// Polling: Her 2 saniyede bir verileri kontrol et (gerçek-zamanlı gibi)
setInterval(() => {
    window.dispatchEvent(new CustomEvent('dataRefresh'));
}, 2000);

// Global window object'ine ata
window.DB = DB;

// ============================================
// Landing Page Logic
// ============================================

async function renderVehicles() {
    try {
        const vehicles = await VehicleManager.load();
        const vehicleList = document.getElementById('vehicle-list');

        if (vehicleList) {
            vehicleList.innerHTML = ''; // Clear existing static content

            vehicles.forEach(vehicle => {
                const vehicleCard = `
                    <div class="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl hover:-translate-y-2 transition-all duration-300 relative">
                        <div class="absolute top-4 left-0 bg-primary text-white px-6 py-2 font-bold text-sm transform -rotate-45 -translate-x-8 translate-y-2 z-10 shadow-lg">
                            %15 İNDİRİM
                    </div>
                    <div class="relative h-56 bg-gray-100">
                        <img src="${vehicle.image}"
                             alt="${vehicle.model}"
                             class="w-full h-full object-cover">
                    </div>
                    <div class="p-6">
                        <h3 class="text-2xl font-bold text-secondary mb-3">${vehicle.model}</h3>
                        <div class="flex items-center gap-4 text-sm text-gray-600 mb-4">
                            <span class="flex items-center gap-1">
                                <i class="ri-user-line"></i> 5 Kişi
                            </span>
                            <span class="flex items-center gap-1">
                                <i class="ri-gas-station-line"></i> Dizel
                            </span>
                            <span class="flex items-center gap-1">
                                <i class="ri-settings-3-line"></i> Manuel
                            </span>
                        </div>
                        <div class="grid grid-cols-2 gap-3 mb-6">
                            <div class="bg-red-50 rounded-lg p-4 text-center">
                                <div class="text-xs text-gray-600 mb-1">Günlük</div>
                                <div class="text-2xl font-bold text-primary">${vehicle.price}</div>
                            </div>
                            <div class="bg-gray-100 rounded-lg p-4 text-center">
                                <div class="text-xs text-gray-600 mb-1">Depozito</div>
                                <div class="text-2xl font-bold text-secondary">${vehicle.deposit}</div>
                            </div>
                        </div>
                        <div class="grid grid-cols-2 gap-3">
                            <a href="tel:+905551234567"
                               class="bg-blue-500 text-white py-3 rounded-lg font-semibold text-center hover:bg-blue-600 transition flex items-center justify-center gap-2">
                                <i class="ri-phone-line"></i>
                                Bizi Arayın
                            </a>
                            <a href="https://wa.me/905551234567"
                               class="bg-whatsapp text-white py-3 rounded-lg font-semibold text-center hover:bg-green-600 transition flex items-center justify-center gap-2">
                                <i class="ri-whatsapp-line"></i>
                                WhatsApp
                            </a>
                        </div>
                    </div>
                </div>
            `;
            vehicleList.innerHTML += vehicleCard;
        });
    }
    } catch (error) {
        console.error('❌ renderVehicles error:', error);
        const vehicleList = document.getElementById('vehicle-list');
        if (vehicleList) {
            vehicleList.innerHTML = `<div class="text-center py-8 col-span-full text-red-500">Hata: ${error.message}</div>`;
        }
    }
}

document.addEventListener('DOMContentLoaded', async function() {
    await renderVehicles();
    
    // Scroll animasyonları - Her bölüme farklı animasyon
    const sections = document.querySelectorAll('section');
    const animations = ['animate-slide-left', 'animate-fade-in', 'animate-slide-up', 'animate-zoom-in', 'animate-bounce-in'];
    
    sections.forEach((section, index) => {
        // İlk section hariç tümünü opacity 0 ile başlat
        if (index !== 0) {
            // Sadece testimonials (index 4) animasyonsuz kalacak
            if (index !== 4) {
                section.style.opacity = '0';
                section.style.transform = 'translateY(30px) translateX(0)';
                section.style.transition = 'none';
                // Eğer data-animation zaten set edilmişse değiştirme
                if (!section.getAttribute('data-animation')) {
                    section.setAttribute('data-animation', animations[index % animations.length]);
                }
            }
        }
    });

    const observerOptions = {
        threshold: 0.15,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const animClass = entry.target.getAttribute('data-animation') || 'animate-fade-in';
                const delay = entry.target.getAttribute('data-delay') || '0s';
                
                entry.target.style.transition = `opacity 1.2s ease-in-out ${delay}, transform 1.2s ease-in-out ${delay}`;
                entry.target.classList.add(animClass);
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0) translateX(0)';
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    // Bölümleri gözle
    sections.forEach((section, index) => {
        if (index !== 0) {
            observer.observe(section);
        }
    });
});

window.addEventListener('storage', async function(e) {
    if (e.key === 'vehicles') {
        await renderVehicles();
    }
});

// Listen for dataChanged event (from other tabs/windows via localStorage)
window.addEventListener('dataChanged', async function(e) {
    if (e.detail.key === 'vehicles') {
        await renderVehicles();
    }
});

// Listen for data refresh from polling (every 2 seconds)
window.addEventListener('dataRefresh', async function() {
    await renderVehicles();
});
