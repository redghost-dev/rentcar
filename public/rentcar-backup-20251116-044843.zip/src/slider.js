// YENİ SLAYT SİSTEMİ - TEMIZ, EFEKTLI, ÇALIŞAN
let currentSlideIndex = 0;
let allSlides = [];
let autoInterval = null;
let isTransitioning = false;

function startSlider() {
    console.log('🎬 startSlider çağrıldı, VehicleManager:', typeof VehicleManager);
    VehicleManager.load().then(vehicles => {
        console.log('✅ Slider VehicleManager.load() döndü:', vehicles);
        allSlides = vehicles.length > 0 ? vehicles : [];
    
    // İlk render
    const container = document.getElementById('heroSlider');
    if (!container) return;
    
    // Slaytları önceden oluştur
    container.innerHTML = allSlides.map((slide, index) => `
        <div id="slide-${index}" style="background-image: url('${slide.image}'); background-size: cover; background-position: center; image-rendering: high-quality; opacity: ${index === 0 ? '1' : '0'}; transition: opacity 500ms ease-in-out;" 
             class="absolute inset-0">
            <div class="absolute inset-0 bg-black/40"></div>
            <div class="container mx-auto px-4 relative z-10 h-full flex items-center">
                <div class="max-w-2xl">
                    <div class="flex items-start justify-between mb-4">
                        <h1 class="text-4xl md:text-6xl font-bold text-white">${slide.model}</h1>
                        <span class="px-3 py-1 rounded-full text-xs font-semibold ${slide.status === 'Müsait' ? 'bg-green-500' : slide.status === 'Kirada' ? 'bg-yellow-500' : 'bg-red-500'} text-white">
                            ${slide.status}
                        </span>
                    </div>
                    <div class="flex items-center gap-1 mb-4">
                        <i class="ri-star-fill text-yellow-300"></i>
                        <span class="text-gray-200">4.8 (250+ değerlendirme)</span>
                    </div>
                    <div class="flex gap-3 mb-6 text-sm md:text-base">
                        <span class="flex items-center gap-1 text-gray-200"><i class="ri-user-line"></i> 5 Kişi</span>
                        <span class="flex items-center gap-1 text-gray-200"><i class="ri-gas-station-line"></i> Dizel</span>
                        <span class="flex items-center gap-1 text-gray-200"><i class="ri-settings-3-line"></i> Manuel</span>
                    </div>
                    <div class="flex gap-4 mb-6">
                        <div class="bg-white/20 backdrop-blur px-4 py-2 rounded">
                            <div class="text-xs text-gray-200">Günlük Ücret</div>
                            <div class="text-2xl font-bold text-yellow-300">${slide.price}</div>
                        </div>
                        <div class="bg-white/20 backdrop-blur px-4 py-2 rounded">
                            <div class="text-xs text-gray-200">Depozito</div>
                            <div class="text-2xl font-bold text-yellow-300">${slide.deposit}</div>
                        </div>
                    </div>
                    <a href="https://wa.me/${SiteSettings.load().whatsappNumber}?text=Merhaba!%20${slide.model}%20aracını%20kiralamak%20istiyorum" target="_blank" 
                       class="inline-flex items-center gap-2 bg-green-500 hover:bg-green-600 text-white px-8 py-3 rounded font-semibold transition">
                        <i class="ri-whatsapp-line"></i> WhatsApp ile Rezerve Et
                    </a>
                </div>
            </div>
        </div>
    `).join('');
    
    renderDots();
    startAutoPlay();
    });
}

function renderDots() {
    const dotsContainer = document.getElementById('sliderDots');
    if (!dotsContainer) return;
    
    let html = '';
    for (let i = 0; i < allSlides.length; i++) {
        html += `<button class="w-3 h-3 rounded-full transition cursor-pointer ${i === currentSlideIndex ? 'bg-white' : 'bg-gray-400'} hover:bg-gray-300" onclick="goToSlide(${i})"></button>`;
    }
    dotsContainer.innerHTML = html;
}

function updateSlideDisplay() {
    const slides = document.querySelectorAll('[id^="slide-"]');
    slides.forEach((slide, index) => {
        if (index === currentSlideIndex) {
            slide.style.opacity = '1';
        } else {
            slide.style.opacity = '0';
        }
    });
    renderDots();
}

function nextSlide() {
    if (isTransitioning) return;
    isTransitioning = true;
    stopAutoPlay();
    currentSlideIndex = (currentSlideIndex + 1) % allSlides.length;
    updateSlideDisplay();
    setTimeout(() => {
        isTransitioning = false;
        startAutoPlay();
    }, 500);
}

function prevSlide() {
    if (isTransitioning) return;
    isTransitioning = true;
    stopAutoPlay();
    currentSlideIndex = (currentSlideIndex - 1 + allSlides.length) % allSlides.length;
    updateSlideDisplay();
    setTimeout(() => {
        isTransitioning = false;
        startAutoPlay();
    }, 500);
}

function goToSlide(index) {
    if (isTransitioning || index === currentSlideIndex) return;
    isTransitioning = true;
    stopAutoPlay();
    currentSlideIndex = index;
    updateSlideDisplay();
    setTimeout(() => {
        isTransitioning = false;
        startAutoPlay();
    }, 500);
}

function changeSlide(direction) {
    console.log('changeSlide called with direction:', direction);
    direction === 1 ? nextSlide() : prevSlide();
}

function startAutoPlay() {
    autoInterval = setInterval(() => {
        if (!isTransitioning) {
            currentSlideIndex = (currentSlideIndex + 1) % allSlides.length;
            updateSlideDisplay();
        }
    }, 5000);
}

function stopAutoPlay() {
    if (autoInterval) clearInterval(autoInterval);
}

document.addEventListener('DOMContentLoaded', () => {
    setTimeout(startSlider, 100);
});

window.addEventListener('storage', (e) => {
    if (e.key === 'vehicles') {
        currentSlideIndex = 0;
        startSlider();
    }
});

// Window global exports
window.changeSlide = changeSlide;
window.goToSlide = goToSlide;
window.nextSlide = nextSlide;
window.prevSlide = prevSlide;
